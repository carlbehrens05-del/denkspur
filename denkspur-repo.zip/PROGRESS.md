# Fortschritt

| Meilenstein | Status |
|---|---|
| Vorbereitung (Gliederung, Schema, Typen, API-Vertrag) | ✅ erledigt (13.11.2026) |
| M0 – Fundament und iPad-Spike | ⏳ als Nächstes |
| M1 – Import, Fäden, Suche, Ordnung ohne KI | offen |
| M2 – Notizen | offen |
| M3 – KI-Schicht | offen |
| M4 – Ansichten | offen |
| M5 – Befehle und Archiv-Chat | offen |
| M6 – Sicherheit und Backup | offen |
| M7 – weitere Quellen | offen |
| M8 – Computer-Begleiter (optional) | offen |

## Vorbereitung – Ergebnis
- `src/core/db/migrations/0001_init.sql`: Schema mit 30 Tabellen und Views, getestet mit SQLite 3.53.1 und FTS5. Die Trigger für Unveränderlichkeit, „nur anhängen“ und Versionen greifen, Duplikate werden erkannt, Korrekturen laufen über `entries_current`, „Nicht von mir“ über `entries_visible`, die Suche findet „uber“ → „über“ (`tools/check_schema.py`).
- `src/core/model/types.ts` und `src/core/api/contract.ts`: fehlerfrei mit `tsc --strict`.
- Noch nicht vorhanden: `package.json`, Build-Setup, jeglicher App-Code (folgt in M0).

## Entscheidungen
- Hosting: _offen (Standard GitHub Pages)_
- KI-Anbieter: _offen (Standard Anthropic, eigener API-Key, erst ab M3 nötig)_
- Name: Denkspur (Arbeitstitel)

## Log
- 13.11.2026: Projekt vorbereitet.
