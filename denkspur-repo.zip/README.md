# Denkspur

Ein persönliches, datiertes Gedankenarchiv aus KI-Chats, Notizen und Sprachmemos, das sich selbst ordnet. Es läuft als Web-App im Browser und auf dem iPad als App vom Home-Bildschirm. Alle Daten bleiben auf dem Gerät.

**Stand:** vorbereitet, noch kein App-Code. Siehe `PROGRESS.md`.

- Plan: `docs/GLIEDERUNG.md`
- Spezifikation: `docs/BAU-PROMPT.md`
- Nächster Schritt: `docs/NAECHSTER-PROMPT.md`
- Regeln für Claude Code: `CLAUDE.md`

_Installation, Deployment und iPad-Test werden in M0 ergänzt._
